package com.senacgrupovinteecinco.PetConnect

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException


class MainActivity : AppCompatActivity() {

    private val baseUrl = "http://10.0.0.102/api.php?entity=login"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        btnLogin.setOnClickListener {
            val email = findViewById<EditText>(R.id.etEmail).text.toString()
            val password = findViewById<EditText>(R.id.etPassword).text.toString()
            loginUser(email, password)
        }
    }

    private fun loginUser(email: String, password: String) {
        val json = JSONObject()
        json.put("email", email)
        json.put("password", password)

        val body = RequestBody.create("application/json; charset=utf-8".toMediaType(), json.toString())
        val request = Request.Builder()
            .url(baseUrl)
            .post(body)
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Erro de rede", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val resBody = response.body?.string()
                runOnUiThread {
                    try {
                        val json = JSONObject(resBody)
                        if (response.isSuccessful && json.has("user")) {
                            val userJson = json.getJSONObject("user")
                            val userId = userJson.getInt("id")         // <- pega o ID do usuário
                            val email = userJson.getString("email")
                            val isAdmin = userJson.optBoolean("is_admin", false)

                            val intent = if (isAdmin) {
                                Intent(this@MainActivity, AdminActivity::class.java)
                            } else {
                                Intent(this@MainActivity, HomeActivity::class.java)
                            }

                            intent.putExtra("userId", userId)          // <- envia userId
                            intent.putExtra("email", email)
                            startActivity(intent)
                            finish()
                        } else {
                            val errorMsg = json.optString("error", "Credenciais inválidas")
                            Toast.makeText(this@MainActivity, errorMsg, Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Erro na resposta do servidor", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

}
