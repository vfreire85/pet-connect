package com.senacgrupovinteecinco.PetConnect

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException

class AdminActivity : AppCompatActivity() {

    private val baseUrl = "http://10.0.0.102/api.php?entity=user"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val btnDelete = findViewById<Button>(R.id.btnDeleteUser)
        btnDelete.setOnClickListener {
            val emailToDelete = findViewById<EditText>(R.id.etDeleteUserEmail).text.toString().trim()
            if (emailToDelete.isNotEmpty()) {
                deleteUser(emailToDelete)
            } else {
                Toast.makeText(this, "Informe o e-mail do usuário", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun confirmAndDelete(userId: Int) {
        val url = "http://10.0.0.102/api.php?entity=user&id=$userId"

        val request = Request.Builder()
            .url(url)
            .delete()
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@AdminActivity, "Erro ao deletar usuário", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        Toast.makeText(this@AdminActivity, "Usuário deletado com sucesso", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@AdminActivity, "Erro ao deletar", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

    private fun deleteUser(email: String) {
        val url = "http://10.0.0.102/api.php?entity=user&email=${Uri.encode(email)}"

        val request = Request.Builder()
            .url(url)
            .delete()
            .build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@AdminActivity, "Erro de rede", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        Toast.makeText(this@AdminActivity, "Usuário deletado com sucesso", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@AdminActivity, "Erro ao deletar usuário", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        })
    }

}
